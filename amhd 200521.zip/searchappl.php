<?php

// Header 
include('login/assets.php');

 
?>

<title>Search Applications</title>

<body>

<div class="container">
<div class="row">
<div class="col-md-12">

<script>
$(document).ready(function(){
    $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("backend-search.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
        $(this).parent(".result").empty();
    });
});
</script>
</head>
<body>
    <div class="form-control search-box" style="border:none">
    <br>
        <input type="text" autocomplete="off" placeholder="Search" class="form-control"/>
        <br><br>
        <div class="result"></div>
    </div>


</div>
</div>
</div>
 <?php
  


 include('login/footer.php');

 ?>

<?php

// Header 
include('login/assets.php');


?>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

<title>Home</title>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
            </ul>

            <ul class="nav flex-column mb-2">

            <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  </a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="formreview.php?view=">  
                <span data-feather="file-text"></span>
              <i class="fa fa-home fa-lg"></i> Home </a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="?view=Pending">  
                <span data-feather="file-text"></span>
              <i class="fa fa-arrows-h fa-lg"></i> Pending </a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="?view=Approved">  
                <span data-feather="file-text"></span>
              <i class="fa fa-check fa-lg"></i> Approved </a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="?view=Rejected">  
                <span data-feather="file-text"></span>
              <i class="fa fa-times fa-lg"></i> Rejected </a>
              </li>
            </ul>
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    

<?php


    $limit = 10;
    $s = $db->prepare("SELECT * FROM hd_0001");
    $s->execute();
    $allResp = $s->fetchAll(PDO::FETCH_ASSOC);
    // echo '<pre>';
    // var_dump($allResp);
    $total_results = $s->rowCount();
 

?>

<div class="container">
  <h2 class="">Health Declaration Form <span class="badge">Total: <?php echo $total_results; ?></span> </h2>

<?php
$filledtoday = $db->prepare("SELECT * FROM hd_0001 WHERE dt_apply LIKE '$currentdate%'");
$filledtoday->execute();
$getfilledtoday = $filledtoday->fetchAll(PDO::FETCH_ASSOC);
$totfilledtoday = $filledtoday->rowCount();

//echo $totfilledtoday;



    $statement = $db->prepare("SELECT company FROM hd_0001");
    $statement->execute();
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $jsontable = json_encode($results);
    echo $jsontable;
     
?>

<script>
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

function drawChart() {

    var data = new google.visualization.DataTable(<?=$jsonTable?>);

    var options = {
      title: ''
    };

    var chart = new google.visualization.BarChart(document.getElementById('piemanpower'));

    chart.draw(data, options);
  }
  </script>


<div id="piemanpower" style="width: 100%; height: 100%;"></div>
<?php

 include('login/footer.php');

 ?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- bootstrap -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 

<!-- jquery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- font awesome -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- google material icon -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


<?php


// Database connection
require __DIR__ . '/login/database.php';
$db = DB();

$currentdt = date('Y-m-d') . ' ' . date('h:i:s');


?>

</head>
<body>

<div class="container">
<div class="row">
<div class="col-md-12">

<br>

<table class="table table-bordered">
    <tr>
    <th scope="col" width="50%" style="text-align:center;"><img src="logoain.png" width="200px"></th>
      <th scope="col" style="text-align:center;">Health Declaration Form <br> (Visitors / Contractors / Service Providers)</th>
    </tr>
</table>

<p align="justify">This Health Declaration Form helps us to ensure a safe experience for you. We urge you to be completely thorough in providing us with the information requested. Failure to disclose any required information could be harmful to you and also our work process. Information provided will be kept in strict confidence.</p>

<h2>Personnel Information</h2>
<hr>
<form method="POST" enctype="multipart/form-data">
  <div class="form-group row">
    <label class="col-4 col-form-label" for="fullname">Full Name (Mr / Mrs.) <br><i>Nama Penuh (En / Puan / Cik)</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-address-card"></i>
          </div>
        </div> 
        <input id="fullname" name="fullname" type="text" required="required" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="mykad" class="col-4 col-form-label">MyKad / Passport No. <br><i>No. MyKad / Passport</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-id-card"></i>
          </div>
        </div> 
        <input id="mykad" name="mykad" type="text" required="required" class="form-control">
      </div>
    </div>
  </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="email" class="col-4 col-form-label">Visiting Office <br><i>Pejabat Kunjungan</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-briefcase"></i>
          </div>
        </div> 
        <select name="visoffice" class="form-control" required>
        <option value="HQ">Headquarters // Ibu Pejabat</option>
        <option value="Northern">Northern Branch // Cawangan Kulim</option>
        </select>
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="email" class="col-4 col-form-label">E-Mail <br><i>E-Mel</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-id-card"></i>
          </div>
        </div> 
        <input id="email" name="appemail" type="text" required="required" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="entryin" class="col-4 col-form-label">Date of Entry <br><i>Tarikh Masuk</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-arrow-right"></i>
          </div>
        </div> 
        <input id="entryin" name="entryin" type="date" required="required" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="entryout" class="col-4 col-form-label">Until <br><i>Sehingga</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-arrow-left"></i>
          </div>
        </div> 
        <input id="entryout" name="entryout" type="date" required="required" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="company" class="col-4 col-form-label">Company / Department <br><i>Organisasi / Syarikat</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-building"></i>
          </div>
        </div> 
        <select name="company" class="form-control">
         <?php 
		 $stmt = $db->prepare("SELECT DISTINCT company FROM hd_0001");
		 $stmt->execute();
     echo "<option value='' selected>List of Company // Senarai Organisasi</option>";
		 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
		 { 
	     extract($row);
		 ?>
           <option value="<?php echo $company; ?>"><?php echo $company; 
		 }
		 ?></option>
         </select>
      </div>
      <br>
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-building"></i>
          </div>
        </div> 
        <input id="company" name="company2" type="text" class="form-control" placeholder="Only fill if your company is not listed // Hanya isi jika organisasi anda tidak tersenarai">
      </div><br>
    </div>
    
  </div>
  <div class="form-group row">
    <label for="caddress" class="col-4 col-form-label">Address <br><i>Alamat</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-compass"></i>
          </div>
        </div> 
        <input id="caddress" name="caddress" type="text" required="required" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="ccity" class="col-4 col-form-label">City <br><i>Bandar</i></label> 
    <div class="col-8">
      <input id="ccity" name="ccity" type="text" required="required" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="cstate" class="col-4 col-form-label">State <br><i>Negeri</i></label> 
    <div class="col-8">
      <input id="cstate" name="cstate" type="text" required="required" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="cpostal" class="col-4 col-form-label">Postal Code <br><i>Poskod</i></label> 
    <div class="col-8">
      <input id="cpostal" name="cpostal" type="text" required="required" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="telno" class="col-4 col-form-label">Telephone No.<br><i>No. Telefon</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-phone-square"></i>
          </div>
        </div> 
        <input id="telno" name="telno" type="text" required="required" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="reasonentry" class="col-4 col-form-label">Reason of Entry <br><i>Nama orang yang dihubungi</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-edit"></i>
          </div>
        </div> 
        <input id="reasonentry" name="reasonentry" type="text" required="required" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="nameconperson" class="col-4 col-form-label">Name of Contact Person <br><i>Alamat email orang yang dihubungi</i></label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-male"></i>
          </div>
        </div> 
        <input id="nameconperson" name="nameconperson" type="text" required="required" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="emailaddconperson" class="col-4 col-form-label">Email Address of Contact Person</label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-envelope"></i>
          </div>
        </div> 
        <input id="emailaddconperson" name="emailaddconperson" type="text" class="form-control">
      </div>
    </div>
  </div> 

  <hr>

  <div class="form-group">
    <label align="justify">Please declare if you or any family members staying with you have been travelling to the countries affected by COVID-19 within 14 days of the declaration. <br><i>Sila nyatakan jika anda atau mana-mana ahli keluarga yang tinggal bersama anda telah melawat ke negara yang terkena wabak COVID-19 dalam masa 14 hari dari pengisytiharan ini.</i></label> 
    <div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="radio1" id="chkYes" type="radio" class="custom-control-input" value="Yes" required="required"> 
        <label for="chkYes" class="custom-control-label">Yes</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="radio1" id="chkNo" type="radio" class="custom-control-input" value="No" required="required"> 
        <label for="chkNo" class="custom-control-label">No</label>
      </div>
    </div>

    <div id="dvChkYes" style="display: none">
    <div class="form-group row">
    <label for="country" class="col-4 col-form-label">Countries <br><i>Negara</i></label> 
    <div class="col-8">
      <input id="country" name="country" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="doafromcountries" class="col-4 col-form-label">Date of arrivals from the state countries <br><i>Tarikh ketibaan dari negara tersebut</i></label> 
    <div class="col-8">
      <input id="doafromcountries" name="doafromcountries" type="date" class="form-control">
    </div>
  </div> 
  </div>
</div> 

<hr>

<div class="form-group">
<label align="justify">Please declare if you or any family member staying with you have been travelling to the COVID-19 red zone / MCO / CMCO areas within 14 days of the declaration. <br><i>Sila nyatakan jika anda atau mana-mana ahli keluarga yang tinggal bersama anda telah pergi ke / dari kawasan zon merah COVID-19 / PKP / PKPD dalam masa 14 hari dari pengisytiharan ini.</i></label> 
    <div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="radio2" id="chkYes2" type="radio" class="custom-control-input" value="Yes" required="required"> 
        <label for="chkYes2" class="custom-control-label">Yes</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="radio2" id="chkNo2" type="radio" class="custom-control-input" value="No" required="required"> 
        <label for="chkNo2" class="custom-control-label">No</label>
      </div>
    </div>

    <div id="dvChkYes2" style="display: none">
    <div class="form-group row">
    <label for="individu" class="col-4 col-form-label">Individual <br> <i>Individu</i></label> 
    <div class="col-8">
      <input id="individu" name="individu" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="areafrom" class="col-4 col-form-label">Area <br> <i>Kawasan</i></label> 
    <div class="col-8">
      <input id="areafrom" name="areafrom" type="text" class="form-control">
    </div>
  </div> 
  </div>
</div>

<hr>

  <div class="form-group">
<label align="justify">Do you have any CLOSE CONTACT with a POSITIVE COVID-19 individual? <br><i>Adakah anda mempunyai KONTAK RAPAT dengan individu POSITIF COVID-19?</i></label> 
    <div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="radio3" id="chkYes3" type="radio" class="custom-control-input" value="Yes" required="required"> 
        <label for="chkYes3" class="custom-control-label">Yes</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="radio3" id="chkNo3" type="radio" class="custom-control-input" value="No" required="required"> 
        <label for="chkNo3" class="custom-control-label">No</label>
      </div>
    </div>
</div>


<hr>

<div class="form-group">
<label align="justify">Have you ever been tested for COVID-19? <br><i>Adakah anda pernah diuji untuk COVID-19? </i></label> 
    <div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="radio4" id="chkYes4" type="radio" class="custom-control-input" value="Yes" required="required"> 
        <label for="chkYes4" class="custom-control-label">Yes</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="radio4" id="chkNo4" type="radio" class="custom-control-input" value="No" required="required"> 
        <label for="chkNo4" class="custom-control-label">No</label>
      </div>
    </div>

    <div id="dvChkYes4" style="display: none">

    <div class="form-group row">
    <label for="rescovid" class="col-4 col-form-label">Result <br> <i>Keputusan</i></label> 
    <div class="col-8">
      <select id="rescovid" name="rescovid" class="custom-select">
        <option value="" selected></option>
        <option value="neg">Negative / Negatif</option>
        <option value="pos">Positive / Positif</option>
      </select>
    </div>
  </div> 

  <div class="form-group row">
    <label for="datetest" class="col-4 col-form-label">Date <br> <i>Tarikh</i></label> 
    <div class="col-8">
      <input id="datetest" name="datetest" type="date" class="form-control">
    </div>
  </div> 
  
  <div class="form-group row">
    <label for="loctest" class="col-4 col-form-label">Location of Testing <br> <i>Lokasi Ujian</i></label> 
    <div class="col-8">
      <input id="loctest" name="loctest" type="text" class="form-control">
    </div>
  </div> 
  
  <div class="form-group row">
  <label for="loctest" class="col-4 col-form-label">COVID-19 Test Result <br> <i>Keputusan Ujian COVID-10</i></label> 
    <div class="col-8">
    <input class="form-control" type="file" name="covtestresult" accept="image/*,.pdf" />
    </div>
  </div> 

  
  </div>
  

</div>

<br><br>

<h2>Symptoms</h2>
<hr>
  <div class="form-group row">
    <label class="col-4">Cough <br><i>Batuk / Batuk Kering</i></label> 
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
        <input name="cough" id="cough_0" type="radio" class="custom-control-input" value="yes" required="required"> 
        <label for="cough_0" class="custom-control-label">Yes</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="cough" id="cough_1" type="radio" class="custom-control-input" value="no" required="required"> 
        <label for="cough_1" class="custom-control-label">No</label>
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label class="col-4">Difficult Breathing <br><i>Kesukaran Bernafas</i></label> 
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
        <input name="diffbreathing" id="diffbreathing_0" type="radio" class="custom-control-input" value="yes" required="required"> 
        <label for="diffbreathing_0" class="custom-control-label">Yes</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="diffbreathing" id="diffbreathing_1" type="radio" class="custom-control-input" value="no" required="required"> 
        <label for="diffbreathing_1" class="custom-control-label">No</label>
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label class="col-4">Fever <br><i>Demam</i></label> 
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
        <input name="fever" id="fever_0" type="radio" class="custom-control-input" value="yes" required="required"> 
        <label for="fever_0" class="custom-control-label">Yes</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="fever" id="fever_1" type="radio" class="custom-control-input" value="no" required="required"> 
        <label for="fever_1" class="custom-control-label">No</label>
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label class="col-4">Flu <br><i>Selesema</i></label> 
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
        <input name="flu" id="flu_0" type="radio" class="custom-control-input" value="yes" required="required"> 
        <label for="flu_0" class="custom-control-label">Yes</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="flu" id="flu_1" type="radio" class="custom-control-input" value="no" required="required"> 
        <label for="flu_1" class="custom-control-label">No</label>
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label class="col-4">Sore Throat <br><i>Sakit Tekak</i></label> 
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
        <input name="sorethroat" id="sorethroat_0" type="radio" class="custom-control-input" value="yes" required="required"> 
        <label for="sorethroat_0" class="custom-control-label">Yes</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="sorethroat" id="sorethroat_1" type="radio" class="custom-control-input" value="no" required="required"> 
        <label for="sorethroat_1" class="custom-control-label">No</label>
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="othersymptoms" class="col-4 col-form-label">Other Symptoms <br><i>Simptom-simptom Lain</i></label> 
    <div class="col-8">
      <textarea id="othersymptoms" name="othersymptoms" cols="40" rows="3" class="form-control"></textarea>
    </div>
  </div> 

  <br>

<h2>
    Declaration and Disclaimer
</h2>
<hr>
<p align="justify">I hereby declare that the information provided are complete and true. I am aware that I will be responsible for all the information given. Should the information declared are found incorrect or manipulated I hereby undertake to take full responsibility and shall be liable for any action taken by the company against me. I am physically fit to participate in this activity, implying that I have no medical or physical conditions. I have consulted a doctor in advance, and I am willing to assume and bear the consequential costs of any risks that may be created, directly or indirectly, by any such condition. By submitting this declaration form, I agree to the collection, use and disclosure of my personal, movement, close contact persons and health information above by Ain Medicare Sdn. Bhd. or other authorised parties by Ain Medicare Sdn. Bhd. for precautionary measure against COVID-19 or other infectious diseases. I shall not take any legal actions against Ain Medicare Sdn. Bhd. or other authorised parties by Ain Medicare Sdn. Bhd. if my personal data being used for any purpose by any parties or disclosure by any parties for whatsoever reason to public without written approval from Ain Medicare Sdn. Bhd. </p>

<br><p align="justify"><i>
Dengan ini saya menyatakan bahawa maklumat yang diberikan adalah lengkap dan benar. Saya sedar bahawa saya akan bertanggungjawab untuk semua maklumat yang diberikan. Sekiranya maklumat yang dinyatakan didapati salah atau dimanipulasi, dengan ini saya berjanji untuk mengambil tanggungjawab penuh dan akan bertanggungjawab atas tindakan yang diambil oleh syarikat terhadap saya. Saya sihat secara fizikal untuk menyertai aktiviti ini, yang bermaksud bahawa saya tidak mempunyai keadaan perubahan atau fizikal dan saya bersedia untuk menanggung kos akibat risiko yang mungkin terhasil secara langsung atau tidak langsung, oleh keadaan sedemikian. Dengan menghantar borang perisytiharan ini, saya bersetuju dengan pengumpulan, penggunaan dan pendedahan peribadi, pergerakan, kontak rapat dan maklumat kesihatan di atas oleh AIN Medicare Sdn.Bhd. atau pihak lain yang diberi kuasa oleh AIN Medicare Sdn. Bhd. untuk langkah berjaga-jaga terhadap COVID-19 atau penyakit berjangkit lain. Saya tidak akan mengambil sebarang tindakan undang-undang terhadap AIN Medicare Sdn. Bhd. atau pihak lain yang diberi kuasa oleh AIN Medicare Sdn.Bhd. sekiranya maklumat peribadi saya digunakan untuk apa-apa tujuan oleh mana-mana pihak atau pendedahan oleh mana-mana pihak dengan alasan apa pun kepada pihak awam tanpa kebenaran bertulis dari AIN Medicare Sdn. Bhd.</i></p>



     <center> <button name="submitBtn" type="submit" class="btn btn-primary">Submit</button> </center>
  <br><br>


</form>




</div>


<script>
$(function() {
   $("input[name='radio1']").click(function() {
     if ($("#chkYes").is(":checked")) {
       $("#dvChkYes").show();
     } else {
       $("#dvChkYes").hide();
     }
   });

   $("input[name='radio2']").click(function() {
     if ($("#chkYes2").is(":checked")) {
       $("#dvChkYes2").show();
     } else {
       $("#dvChkYes2").hide();
     }
   });

   $("input[name='radio4']").click(function() {
     if ($("#chkYes4").is(":checked")) {
       $("#dvChkYes4").show();
     } else {
       $("#dvChkYes4").hide();
     }
   });
 });
</script>


<?php


if(isset($_POST['submitBtn']))
{
		$fullname = $_POST['fullname'];
		$mykad = $_POST['mykad'];
		$visoffice = $_POST['visoffice'];
		$appemail = $_POST['appemail'];
		$entryin = strtotime($_POST['entryin']);
		$entryin = date('Y-m-d', $entryin); 
		$entryout = strtotime($_POST['entryout']);
		$entryout = date('Y-m-d', $entryout); 
		$company = $_POST['company'];
		$company2 = $_POST['company2'];
		$caddress = $_POST['caddress'];
		$ccity = $_POST['ccity'];
		$cstate = $_POST['cstate'];
		$cpostal = $_POST['cpostal'];
		$telno = $_POST['telno'];
		$reasonentry = $_POST['reasonentry'];
		$nameconperson = $_POST['nameconperson'];
		$emailaddconperson = $_POST['emailaddconperson'];
		$radio1 = $_POST['radio1'];
		$country = $_POST['country'];
		$doafromcountries = strtotime($_POST['doafromcountries']);
		$doafromcountries = date('Y-m-d', $doafromcountries); 
    if($doafromcountries == "1970-01-01"){
      $doafromcountries = "";
    } 
		$radio2 = $_POST['radio2'];
		$individu = $_POST['individu'];
		$areafrom = $_POST['areafrom'];
		$radio3 = $_POST['radio3'];
		$radio4 = $_POST['radio4'];
		$rescovid = $_POST['rescovid'];
		$datetest = strtotime($_POST['datetest']);
		$datetest = date('Y-m-d', $datetest); 
    if($datetest == "1970-01-01"){
      $datetest = "";
    }
		$loctest = $_POST['loctest'];
		$cough = $_POST['cough'];
		$diffbreathing = $_POST['diffbreathing'];
		$fever = $_POST['fever'];
		$flu = $_POST['flu'];
		$sorethroat = $_POST['sorethroat'];
		$othersymptoms = $_POST['othersymptoms'];

    $dt_apply = $currentdt;

    // company name

    if(($company != "") && ($company2 != "")){
      $company = $company;
    } else if($company != ""){
      $company = $company;
    } else {
      $company = $company2;
    }

    // test result document

    $imgFile = $_FILES['covtestresult']['name'];
    $tmp_dir = $_FILES['covtestresult']['tmp_name'];
    $imgSize = $_FILES['covtestresult']['size'];

    $upload_dir = 'uploadedfiles/'; // upload directory
   
   if($imgExt != ""){
   $imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
  
   // valid image extensions
   $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'pdf'); // valid extensions
  
   // rename uploading image
   $covtestresult = rand(1000,1000000).".".$imgExt;
    
   // allow valid image file formats
   if(in_array($imgExt, $valid_extensions)){   
    // Check file size '5MB'
    if($imgSize < 5000000)    {
     move_uploaded_file($tmp_dir,$upload_dir.$covtestresult);
    }
    else{
      echo '<script>alert("Your file is too large. Please try again. // Fail anda terlalu besar. Sila cuba lagi.");</script>';
    }
   }
   else{
    echo '<script>alert("Sorry, only JPG, JPEG, PNG, GIF & PDF files are allowed. // Maaf, hanya fail JPG, JPEG, PNG, GIF & PDF sahaja yang dibenarkan.");</script>';
   }
   } else {
       $covtestresult = "";
   }

   // file upload finish


   // get last id to create reference number

   $getlastid = $db->prepare("SELECT hd_id FROM hd_0001 ORDER BY hd_id DESC LIMIT 1;");
   $getlastid->execute();
   $rowlastid=$getlastid->fetch(PDO::FETCH_ASSOC);
   $lastid = $rowlastid['hd_id'] + 1;
   
   $refnum = "HD" . date('y') . $lastid;

    /*try {*/
      $query = $db->prepare("INSERT INTO hd_0001(refnum,fullname,mykad,visoffice,appemail,entryin,entryout,company,caddress,ccity,cstate,cpostal,telno,reasonentry,nameconperson,emailaddconperson,radio1,country,doafromcountries,radio2,individu,areafrom,radio3,radio4,rescovid,datetest,loctest,cough,diffbreathing,fever,flu,sorethroat,othersymptoms,dt_apply,covtestresult) VALUES (:refnum,:fullname,:mykad,:visoffice,:appemail,:entryin,:entryout,:company,:caddress,:ccity,:cstate,:cpostal,:telno,:reasonentry,:nameconperson,:emailaddconperson,:radio1,:country,:doafromcountries,:radio2,:individu,:areafrom,:radio3,:radio4,:rescovid,:datetest,:loctest,:cough,:diffbreathing,:fever,:flu,:sorethroat,:othersymptoms,:dt_apply,:covtestresult)");
      $query->bindParam("refnum", $refnum);
      $query->bindParam("fullname", $fullname);
      $query->bindParam("mykad", $mykad);
      $query->bindParam("visoffice", $visoffice);
      $query->bindParam("appemail", $appemail);
      $query->bindParam("entryin", $entryin);
      $query->bindParam("entryout", $entryout);
      $query->bindParam("company", $company);
      $query->bindParam("caddress", $caddress);
      $query->bindParam("ccity", $ccity);
      $query->bindParam("cstate", $cstate);
      $query->bindParam("cpostal", $cpostal);
      $query->bindParam("telno", $telno);
      $query->bindParam("reasonentry", $reasonentry);
      $query->bindParam("nameconperson", $nameconperson);
      $query->bindParam("emailaddconperson", $emailaddconperson);
      $query->bindParam("radio1", $radio1);
      $query->bindParam("country", $country);
      $query->bindParam("doafromcountries", $doafromcountries);
      $query->bindParam("radio2", $radio2);
      $query->bindParam("individu", $individu);
      $query->bindParam("areafrom", $areafrom);
      $query->bindParam("radio3", $radio3);
      $query->bindParam("radio4", $radio4);
      $query->bindParam("rescovid", $rescovid);
      $query->bindParam("datetest", $datetest);
      $query->bindParam("loctest", $loctest);
      $query->bindParam("cough", $cough);
      $query->bindParam("diffbreathing", $diffbreathing);
      $query->bindParam("fever", $fever);
      $query->bindParam("flu", $flu);
      $query->bindParam("sorethroat", $sorethroat);
      $query->bindParam("othersymptoms", $othersymptoms);
      $query->bindParam("dt_apply", $dt_apply);
      $query->bindParam("covtestresult", $covtestresult);
     
      if($query->execute())
      {
       // return $db->lastInsertId();

      echo '<script>alert("[REFNUM: ' . $refnum . '] Your application has been recorded. Thank you. // Permohonan anda telah disimpan. Terima kasih.");</script>';

      echo "<script>setTimeout(function(){window.location.href = 'index.php';}, 3000); </script>";

    $from = "hello@hzxr.xyz";
    $to = "syaffiqhazari@ainmedicare.com.my";
    $subject = "Health Declaration Form";
    $message = " Salam and greetings. 
    
    New Health Declaration application form has been submitted. Form can be viewed in the link below. Please be noted to login prior reviewing.
    
    http://hzxr.xyz/amhdf/manageappl.php?view_id=" .$refnum. "
    
    Thank you. ";
    $headers = "From:" . $from;
    mail($to,$subject,$message, $headers);
    
      } else {
        print_r($query->errorInfo());
      }



 /*   
    from try, to get error
  } catch (PDOException $e) {
      exit($e->getMessage());
  }

*/

  
}


    ?>
<br><br>

<?php

// Header 
include('login/footer.php');

?>